-- WARNING: this drops and recreates ClinicDB (fine while it only has sample data)
DROP DATABASE IF EXISTS ClinicDB;
CREATE DATABASE ClinicDB;
USE ClinicDB;

CREATE TABLE Patient (
    patient_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    age INT,
    gender VARCHAR(10),
    phone VARCHAR(15),
    email VARCHAR(100) UNIQUE
);

CREATE TABLE Doctor (
    doctor_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    phone VARCHAR(15),
    cabin_no VARCHAR(20),
    available_days VARCHAR(100),
    start_time TIME,
    end_time TIME
);

CREATE TABLE Appointment (
    appointment_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_start_time TIME NOT NULL,
    appointment_end_time TIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Booked',
    FOREIGN KEY (patient_id) REFERENCES Patient(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctor(doctor_id),
    CHECK (appointment_end_time > appointment_start_time),
    CHECK (status IN ('Booked', 'Completed', 'Cancelled', 'No-Show'))
);

CREATE TABLE Medical_Record (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_id INT UNIQUE,
    diagnosis TEXT,
    prescription TEXT,
    visit_notes TEXT,
    record_date DATE NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES Patient(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctor(doctor_id),
    FOREIGN KEY (appointment_id) REFERENCES Appointment(appointment_id)
);

-- Sample data
INSERT INTO Patient (name, age, gender, phone, email) VALUES
('Arun', 25, 'Male', '9876543210', 'arun@gmail.com'),
('Priya', 30, 'Female', '9876543211', 'priya@gmail.com'),
('Karthik', 40, 'Male', '9876543212', 'karthik@gmail.com');

INSERT INTO Doctor (name, specialization, phone, cabin_no, available_days, start_time, end_time) VALUES
('Dr. Kumar', 'Cardiologist', '9876500001', 'A-101', 'Monday,Wednesday,Friday', '09:00:00', '13:00:00'),
('Dr. Priya', 'Dermatologist', '9876500002', 'B-204', 'Tuesday,Thursday,Saturday', '10:00:00', '16:00:00');

INSERT INTO Appointment
(patient_id, doctor_id, appointment_date, appointment_start_time, appointment_end_time, status) VALUES
(1, 1, '2026-10-23', '10:00:00', '10:30:00', 'Booked'),
(2, 2, '2026-10-24', '11:00:00', '11:30:00', 'Booked'),
(3, 1, '2026-10-26', '11:00:00', '11:30:00', 'Booked');

-- Useful queries
SELECT * FROM Patient;
SELECT * FROM Doctor;
SELECT * FROM Appointment;
SELECT * FROM Medical_Record;

SELECT
    A.appointment_id,
    P.name AS patient_name,
    D.name AS doctor_name,
    D.specialization,
    D.cabin_no,
    A.appointment_date,
    A.appointment_start_time,
    A.appointment_end_time,
    A.status
FROM Appointment A
JOIN Patient P ON A.patient_id = P.patient_id
JOIN Doctor D ON A.doctor_id = D.doctor_id;

SELECT
    A.appointment_id,
    P.name AS patient_name,
    D.name AS doctor_name,
    A.appointment_date,
    A.appointment_start_time,
    A.appointment_end_time,
    A.status
FROM Appointment A
JOIN Patient P ON A.patient_id = P.patient_id
JOIN Doctor D ON A.doctor_id = D.doctor_id
WHERE P.patient_id = 1;

SELECT * FROM Doctor WHERE specialization = 'Cardiologist';

SELECT
    P.name AS patient_name,
    D.name AS doctor_name,
    M.diagnosis,
    M.prescription,
    M.visit_notes,
    M.record_date
FROM Medical_Record M
JOIN Patient P ON M.patient_id = P.patient_id
JOIN Doctor D ON M.doctor_id = D.doctor_id
WHERE P.patient_id = 1
ORDER BY M.record_date DESC;
