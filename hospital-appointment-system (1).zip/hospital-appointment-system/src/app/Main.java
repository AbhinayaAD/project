package app;

import dao.AppointmentDAO;
import dao.DoctorDAO;
import dao.PatientDAO;
import model.*;
import service.AppointmentService;
import service.MedicalRecordService;
import service.StatisticsService;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class Main {
    private static final Scanner in = new Scanner(System.in);
    private static final PatientDAO patientDAO = new PatientDAO();
    private static final DoctorDAO doctorDAO = new DoctorDAO();
    private static final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private static final AppointmentService appointmentService = new AppointmentService();
    private static final StatisticsService statsService = new StatisticsService();
    private static final MedicalRecordService recordService = new MedicalRecordService();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n===== HOSPITAL APPOINTMENT SYSTEM =====");
            System.out.println("1. Patients");
            System.out.println("2. Doctors");
            System.out.println("3. Appointments");
            System.out.println("4. Medical records");
            System.out.println("5. Statistics dashboard");
            System.out.println("0. Exit");
            int choice = readInt("Choose: ");
            try {
                switch (choice) {
                    case 1: patientMenu(); break;
                    case 2: doctorMenu(); break;
                    case 3: appointmentMenu(); break;
                    case 4: recordMenu(); break;
                    case 5: dashboard(); break;
                    case 0: System.out.println("Goodbye."); return;
                    default: System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    // ================= PATIENTS =================
    private static void patientMenu() throws Exception {
        System.out.println("\n-- Patients --  1.Add  2.View all  3.Update  0.Back");
        switch (readInt("Choose: ")) {
            case 1:
                Patient p = new Patient();
                p.setName(readText("Name: "));
                p.setAge(readInt("Age: "));
                p.setGender(readText("Gender: "));
                p.setPhone(readText("Phone: "));
                p.setEmail(blankToNull(readText("Email (blank for none): ")));
                patientDAO.add(p);
                System.out.println("Patient added with ID " + p.getPatientId());
                break;
            case 2:
                System.out.printf("%-4s %-20s %-4s %-8s %-12s %s%n", "ID", "Name", "Age", "Gender", "Phone", "Email");
                for (Patient x : patientDAO.getAll()) {
                    System.out.printf("%-4d %-20s %-4d %-8s %-12s %s%n", x.getPatientId(), x.getName(),
                            x.getAge(), x.getGender(), x.getPhone(), x.getEmail());
                }
                break;
            case 3:
                Patient u = patientDAO.getById(readInt("Patient ID: "));
                if (u == null) { System.out.println("Patient not found."); break; }
                System.out.println("Press Enter to keep the current value.");
                u.setName(keep("Name", u.getName()));
                u.setAge(Integer.parseInt(keep("Age", String.valueOf(u.getAge()))));
                u.setGender(keep("Gender", u.getGender()));
                u.setPhone(keep("Phone", u.getPhone()));
                u.setEmail(blankToNull(keep("Email", u.getEmail())));
                patientDAO.update(u);
                System.out.println("Patient updated.");
                break;
            default: break;
        }
    }

    // ================= DOCTORS =================
    private static void doctorMenu() throws Exception {
        System.out.println("\n-- Doctors --  1.Add  2.View all  3.Update  0.Back");
        switch (readInt("Choose: ")) {
            case 1:
                Doctor d = new Doctor();
                d.setName(readText("Name: "));
                d.setSpecialization(readText("Specialization: "));
                d.setPhone(readText("Phone: "));
                d.setCabinNo(readText("Cabin no: "));
                d.setAvailableDays(readText("Available days (e.g. Monday,Wednesday,Friday): "));
                d.setStartTime(readTime("Start time (HH:mm): "));
                d.setEndTime(readTime("End time (HH:mm): "));
                doctorDAO.add(d);
                System.out.println("Doctor added with ID " + d.getDoctorId());
                break;
            case 2:
                System.out.printf("%-4s %-14s %-15s %-8s %-26s %s%n", "ID", "Name", "Specialization", "Cabin", "Days", "Hours");
                for (Doctor x : doctorDAO.getAll()) {
                    System.out.printf("%-4d %-14s %-15s %-8s %-26s %s-%s%n", x.getDoctorId(), x.getName(),
                            x.getSpecialization(), x.getCabinNo(), x.getAvailableDays(), x.getStartTime(), x.getEndTime());
                }
                break;
            case 3:
                Doctor u = doctorDAO.getById(readInt("Doctor ID: "));
                if (u == null) { System.out.println("Doctor not found."); break; }
                System.out.println("Press Enter to keep the current value.");
                u.setName(keep("Name", u.getName()));
                u.setSpecialization(keep("Specialization", u.getSpecialization()));
                u.setPhone(keep("Phone", u.getPhone()));
                u.setCabinNo(keep("Cabin no", u.getCabinNo()));
                u.setAvailableDays(keep("Available days", u.getAvailableDays()));
                u.setStartTime(LocalTime.parse(keep("Start time", u.getStartTime().toString())));
                u.setEndTime(LocalTime.parse(keep("End time", u.getEndTime().toString())));
                doctorDAO.update(u);
                System.out.println("Doctor updated.");
                break;
            default: break;
        }
    }

    // ================= APPOINTMENTS =================
    private static void appointmentMenu() throws Exception {
        System.out.println("\n-- Appointments --");
        System.out.println("1.Book  2.View all  3.Reschedule  4.Cancel  5.Mark completed  6.Mark no-show  0.Back");
        switch (readInt("Choose: ")) {
            case 1:
                Appointment a = new Appointment();
                a.setPatientId(readInt("Patient ID: "));
                a.setDoctorId(readInt("Doctor ID: "));
                a.setAppointmentDate(readDate("Date (yyyy-MM-dd): "));
                a.setStartTime(readTime("Start time (HH:mm): "));
                a.setEndTime(readTime("End time (HH:mm): "));
                String err = appointmentService.book(a);
                System.out.println(err == null ? "Booked. Appointment ID " + a.getAppointmentId() : "Cannot book: " + err);
                break;
            case 2:
                printAppointments();
                break;
            case 3:
                int id = readInt("Appointment ID: ");
                String e2 = appointmentService.reschedule(id, readDate("New date (yyyy-MM-dd): "),
                        readTime("New start (HH:mm): "), readTime("New end (HH:mm): "));
                System.out.println(e2 == null ? "Rescheduled." : "Cannot reschedule: " + e2);
                break;
            case 4:
                System.out.println(appointmentService.cancel(readInt("Appointment ID: "))
                        ? "Cancelled." : "Not found, or not in Booked status.");
                break;
            case 5:
                System.out.println(appointmentService.complete(readInt("Appointment ID: "))
                        ? "Marked completed." : "Not found, or not in Booked status.");
                break;
            case 6:
                System.out.println(appointmentService.markNoShow(readInt("Appointment ID: "))
                        ? "Marked no-show." : "Not found, or not in Booked status.");
                break;
            default: break;
        }
    }

    private static void printAppointments() throws Exception {
        Map<Integer, String> patients = patientNames();
        Map<Integer, String> doctors = doctorNames();
        System.out.printf("%-4s %-16s %-14s %-11s %-6s %-6s %s%n", "ID", "Patient", "Doctor", "Date", "Start", "End", "Status");
        for (Appointment x : appointmentService.getAll()) {
            System.out.printf("%-4d %-16s %-14s %-11s %-6s %-6s %s%n", x.getAppointmentId(),
                    patients.get(x.getPatientId()), doctors.get(x.getDoctorId()), x.getAppointmentDate(),
                    x.getStartTime().toString().substring(0, 5), x.getEndTime().toString().substring(0, 5), x.getStatus());
        }
    }

    // ================= MEDICAL RECORDS =================
    private static void recordMenu() throws Exception {
        System.out.println("\n-- Medical records --  1.Add  2.View by patient  3.Update  0.Back");
        switch (readInt("Choose: ")) {
            case 1:
                int appId = readInt("Completed appointment ID: ");
                String err = recordService.addRecord(appId, readText("Diagnosis: "),
                        readText("Prescription: "), readText("Visit notes: "));
                System.out.println(err == null ? "Record added." : "Cannot add: " + err);
                break;
            case 2:
                List<MedicalRecord> records = recordService.getByPatient(readInt("Patient ID: "));
                if (records.isEmpty()) System.out.println("No records found.");
                for (MedicalRecord r : records) {
                    System.out.println("Record " + r.getRecordId() + " | " + r.getRecordDate()
                            + " | Appointment " + r.getAppointmentId());
                    System.out.println("  Diagnosis:    " + r.getDiagnosis());
                    System.out.println("  Prescription: " + r.getPrescription());
                    System.out.println("  Notes:        " + r.getVisitNotes());
                }
                break;
            case 3:
                int rid = readInt("Record ID: ");
                String e2 = recordService.updateRecord(rid, readText("Diagnosis: "),
                        readText("Prescription: "), readText("Visit notes: "));
                System.out.println(e2 == null ? "Record updated." : "Cannot update: " + e2);
                break;
            default: break;
        }
    }

    // ================= STATISTICS DASHBOARD =================
    private static void dashboard() throws Exception {
        System.out.println("\nDate filter (press Enter to skip a limit)");
        LocalDate from = readOptionalDate("From (yyyy-MM-dd): ");
        LocalDate to = readOptionalDate("To   (yyyy-MM-dd): ");

        List<Appointment> list = statsService.filterByDate(appointmentDAO.getAll(), from, to);
        List<Doctor> doctors = doctorDAO.getAll();
        Map<Integer, String> patients = patientNames();
        Map<Integer, String> doctorNames = doctorNames();

        System.out.println("\n========== STATISTICS DASHBOARD ==========");
        System.out.println("Period: " + (from == null ? "start" : from) + " to " + (to == null ? "end" : to));
        System.out.println("Total patients registered : " + patientDAO.getAll().size());
        System.out.println("Total appointments        : " + statsService.totalAppointments(list));
        System.out.printf("Cancellation rate         : %.1f%%%n", statsService.cancellationRate(list));
        System.out.printf("No-show rate              : %.1f%%%n", statsService.noShowRate(list));

        int[] rf = statsService.repeatVsFirstTime(list);
        System.out.println("Repeat patients           : " + rf[0]);
        System.out.println("First-time patients       : " + rf[1]);

        System.out.println("\n-- Frequent visitors (top 5) --");
        for (Map.Entry<Integer, Integer> e : statsService.frequentVisitors(list, 5)) {
            System.out.println("  " + patients.get(e.getKey()) + " : " + e.getValue() + " visit(s)");
        }

        System.out.println("\n-- Patients grouped by visit frequency --");
        for (Map.Entry<String, List<Integer>> g : statsService.groupByFrequency(list).entrySet()) {
            List<String> names = new ArrayList<>();
            for (int pid : g.getValue()) names.add(patients.get(pid));
            System.out.println("  " + g.getKey() + " : " + (names.isEmpty() ? "-" : String.join(", ", names)));
        }

        System.out.println("\n-- Doctor workload and utilization --");
        Map<Integer, int[]> workload = statsService.workloadPerDoctor(list);
        Map<Integer, Double> util = statsService.utilizationPerDoctor(list, doctors, from, to);
        for (Doctor d : doctors) {
            int[] w = workload.getOrDefault(d.getDoctorId(), new int[2]);
            System.out.printf("  %-12s appointments: %-3d booked minutes: %-5d utilization: %.1f%%%n",
                    doctorNames.get(d.getDoctorId()), w[0], w[1], util.getOrDefault(d.getDoctorId(), 0.0));
        }

        System.out.println("\n-- Peak times --");
        Map<Integer, Integer> hours = statsService.busiestHours(list);
        Integer peakHour = statsService.peak(hours);
        System.out.println("  Busiest hour : " + (peakHour == null ? "-" : String.format("%02d:00-%02d:59 (%d appts)",
                peakHour, peakHour, hours.get(peakHour))));
        Map<DayOfWeek, Integer> days = statsService.busiestDays(list);
        DayOfWeek peakDay = statsService.peak(days);
        System.out.println("  Busiest day  : " + (peakDay == null ? "-" : peakDay + " (" + days.get(peakDay) + " appts)"));

        System.out.println("\n-- Appointments per day --");
        statsService.appointmentsPerDay(list).forEach((k, v) -> System.out.println("  " + k + " : " + v));
        System.out.println("-- Appointments per week --");
        statsService.appointmentsPerWeek(list).forEach((k, v) -> System.out.println("  " + k + " : " + v));
        System.out.println("-- Appointments per month --");
        statsService.appointmentsPerMonth(list).forEach((k, v) -> System.out.println("  " + k + " : " + v));
    }

    // ================= HELPERS =================
    private static Map<Integer, String> patientNames() throws Exception {
        Map<Integer, String> m = new HashMap<>();
        for (Patient p : patientDAO.getAll()) m.put(p.getPatientId(), p.getName());
        return m;
    }

    private static Map<Integer, String> doctorNames() throws Exception {
        Map<Integer, String> m = new HashMap<>();
        for (Doctor d : doctorDAO.getAll()) m.put(d.getDoctorId(), d.getName());
        return m;
    }

    private static String readText(String prompt) {
        System.out.print(prompt);
        return in.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(readText(prompt));
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private static LocalDate readDate(String prompt) {
        while (true) {
            try {
                return LocalDate.parse(readText(prompt));
            } catch (Exception e) {
                System.out.println("Use the format yyyy-MM-dd, e.g. 2026-10-26.");
            }
        }
    }

    private static LocalDate readOptionalDate(String prompt) {
        while (true) {
            String s = readText(prompt);
            if (s.isEmpty()) return null;
            try {
                return LocalDate.parse(s);
            } catch (Exception e) {
                System.out.println("Use the format yyyy-MM-dd, or press Enter to skip.");
            }
        }
    }

    private static LocalTime readTime(String prompt) {
        while (true) {
            try {
                return LocalTime.parse(readText(prompt));
            } catch (Exception e) {
                System.out.println("Use the format HH:mm, e.g. 10:30.");
            }
        }
    }

    // Shows the current value; pressing Enter keeps it
    private static String keep(String label, String current) {
        String s = readText(label + " [" + current + "]: ");
        return s.isEmpty() ? current : s;
    }

    private static String blankToNull(String s) {
        return (s == null || s.trim().isEmpty() || "null".equals(s)) ? null : s;
    }
}
