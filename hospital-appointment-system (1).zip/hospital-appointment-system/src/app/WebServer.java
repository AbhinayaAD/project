package app;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import dao.AppointmentDAO;
import dao.DoctorDAO;
import dao.MedicalRecordDAO;
import dao.PatientDAO;
import model.Appointment;
import model.Doctor;
import model.MedicalRecord;
import model.Patient;
import service.AppointmentService;
import service.MedicalRecordService;
import service.StatisticsService;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.*;

// Web version of the app: serves the frontend (folder "frontend") and a JSON API under /api.
// Run this class, then open http://localhost:8080
public class WebServer {
    private static final int PORT = 8080;

    private static final PatientDAO patientDAO = new PatientDAO();
    private static final DoctorDAO doctorDAO = new DoctorDAO();
    private static final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private static final MedicalRecordDAO recordDAO = new MedicalRecordDAO();
    private static final AppointmentService appointmentService = new AppointmentService();
    private static final MedicalRecordService recordService = new MedicalRecordService();
    private static final StatisticsService statsService = new StatisticsService();

    // An error that should be sent to the browser with a specific HTTP status
    static class ApiException extends Exception {
        final int status;
        ApiException(int status, String message) {
            super(message);
            this.status = status;
        }
    }

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/api/", WebServer::handleApi);
        server.createContext("/", WebServer::handleStatic);
        server.start();
        System.out.println("CarePoint Clinic is running. Open http://localhost:" + PORT + " in your browser.");
        System.out.println("Press Ctrl+C to stop.");
    }

    // ================= HTTP plumbing =================

    private static void handleApi(HttpExchange ex) throws IOException {
        if (ex.getRequestMethod().equals("OPTIONS")) {
            send(ex, 204, "text/plain", new byte[0]);
            return;
        }
        int status = 200;
        String body;
        try {
            body = route(ex);
        } catch (ApiException e) {
            status = e.status;
            body = errorJson(e.getMessage());
        } catch (SQLException e) {
            status = 400;
            body = errorJson(friendly(e));
        } catch (Exception e) {
            e.printStackTrace();
            status = 500;
            body = errorJson("Unexpected server error: " + e.getMessage());
        }
        send(ex, status, "application/json; charset=utf-8", body.getBytes(StandardCharsets.UTF_8));
    }

    private static void handleStatic(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        if (path.equals("/")) path = "/index.html";
        Path root = Paths.get(System.getProperty("frontend.dir", "frontend")).toAbsolutePath().normalize();
        Path file = root.resolve(path.substring(1)).normalize();
        if (!file.startsWith(root) || !Files.isRegularFile(file)) {
            send(ex, 404, "text/plain; charset=utf-8", "Not found".getBytes(StandardCharsets.UTF_8));
            return;
        }
        send(ex, 200, contentType(file.toString()), Files.readAllBytes(file));
    }

    private static String contentType(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html")) return "text/html; charset=utf-8";
        if (n.endsWith(".css")) return "text/css; charset=utf-8";
        if (n.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        return "application/octet-stream";
    }

    private static void send(HttpExchange ex, int status, String type, byte[] data) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
        ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
        if (status == 204) {
            ex.sendResponseHeaders(204, -1);
            ex.close();
            return;
        }
        ex.sendResponseHeaders(status, data.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(data);
        }
    }

    private static String friendly(SQLException e) {
        String m = String.valueOf(e.getMessage());
        if (m.contains("Duplicate entry")) return "That value is already in use (for example, a duplicate email).";
        return m;
    }

    // ================= Routing =================

    private static String route(HttpExchange ex) throws Exception {
        String path = ex.getRequestURI().getPath();
        String[] p = path.length() > 5 ? path.substring(5).split("/") : new String[]{""};
        String m = ex.getRequestMethod();
        Map<String, String> query = parseForm(ex.getRequestURI().getRawQuery());
        Map<String, String> f = (m.equals("POST") || m.equals("PUT"))
                ? parseForm(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8))
                : new HashMap<>();

        switch (p[0]) {
            case "patients": return patients(m, p, f);
            case "doctors": return doctors(m, p, f);
            case "appointments": return appointments(m, p, f, query);
            case "records": return records(m, p, f, query);
            case "stats": return stats(query);
            default: throw new ApiException(404, "Unknown endpoint.");
        }
    }

    // ---------- Patients ----------
    private static String patients(String m, String[] p, Map<String, String> f) throws Exception {
        if (m.equals("GET") && p.length == 1) {
            List<String> items = new ArrayList<>();
            for (Patient x : patientDAO.getAll()) items.add(patientJson(x));
            return "[" + String.join(",", items) + "]";
        }
        if (m.equals("POST") && p.length == 1) {
            Patient x = patientFrom(f);
            patientDAO.add(x);
            return patientJson(x);
        }
        if (m.equals("PUT") && p.length == 2) {
            int id = toInt(p[1], "id");
            if (patientDAO.getById(id) == null) throw new ApiException(404, "Patient not found.");
            Patient x = patientFrom(f);
            x.setPatientId(id);
            patientDAO.update(x);
            return patientJson(x);
        }
        throw new ApiException(405, "Method not allowed.");
    }

    private static Patient patientFrom(Map<String, String> f) throws ApiException {
        Patient x = new Patient();
        x.setName(required(f, "name", "Name"));
        int age = toInt(required(f, "age", "Age"), "Age");
        if (age < 0 || age > 125) throw new ApiException(400, "Age must be between 0 and 125.");
        x.setAge(age);
        String gender = optional(f, "gender");
        if (gender != null && gender.length() > 10) throw new ApiException(400, "Gender must be Male, Female or Other.");
        x.setGender(gender);
        String phone = required(f, "phone", "Phone");
        if (!phone.matches("[0-9]{10}")) throw new ApiException(400, "Phone must be exactly 10 digits.");
        x.setPhone(phone);
        String email = optional(f, "email");
        if (email != null && !email.contains("@")) throw new ApiException(400, "Email is not valid.");
        x.setEmail(email);
        return x;
    }

    // ---------- Doctors ----------
    private static String doctors(String m, String[] p, Map<String, String> f) throws Exception {
        if (m.equals("GET") && p.length == 1) {
            List<String> items = new ArrayList<>();
            for (Doctor d : doctorDAO.getAll()) items.add(doctorJson(d));
            return "[" + String.join(",", items) + "]";
        }
        if (m.equals("POST") && p.length == 1) {
            Doctor d = doctorFrom(f);
            doctorDAO.add(d);
            return doctorJson(d);
        }
        if (m.equals("PUT") && p.length == 2) {
            int id = toInt(p[1], "id");
            if (doctorDAO.getById(id) == null) throw new ApiException(404, "Doctor not found.");
            Doctor d = doctorFrom(f);
            d.setDoctorId(id);
            doctorDAO.update(d);
            return doctorJson(d);
        }
        throw new ApiException(405, "Method not allowed.");
    }

    private static Doctor doctorFrom(Map<String, String> f) throws ApiException {
        Doctor d = new Doctor();
        d.setName(required(f, "name", "Name"));
        d.setSpecialization(required(f, "specialization", "Specialization"));
        String phone = required(f, "phone", "Phone");
        if (!phone.matches("[0-9]{10}")) throw new ApiException(400, "Phone must be exactly 10 digits.");
        d.setPhone(phone);
        d.setCabinNo(required(f, "cabinNo", "Cabin no"));
        String days = optional(f, "availableDays");
        if (days == null) throw new ApiException(400, "Select at least one available day.");
        d.setAvailableDays(normalizeDays(days));
        d.setStartTime(toTime(required(f, "startTime", "Start time")));
        d.setEndTime(toTime(required(f, "endTime", "End time")));
        if (!d.getEndTime().isAfter(d.getStartTime())) throw new ApiException(400, "End time must be after start time.");
        return d;
    }

    // "monday, FRIDAY" -> "Monday,Friday"; rejects anything that is not a day name
    private static String normalizeDays(String raw) throws ApiException {
        List<String> out = new ArrayList<>();
        for (String part : raw.split(",")) {
            String d = part.trim();
            if (d.isEmpty()) continue;
            boolean ok = false;
            for (DayOfWeek day : DayOfWeek.values()) {
                String full = day.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
                if (full.equalsIgnoreCase(d)) {
                    out.add(full);
                    ok = true;
                    break;
                }
            }
            if (!ok) throw new ApiException(400, "'" + d + "' is not a valid day name.");
        }
        if (out.isEmpty()) throw new ApiException(400, "Select at least one available day.");
        return String.join(",", out);
    }

    // ---------- Appointments ----------
    private static String appointments(String m, String[] p, Map<String, String> f, Map<String, String> q)
            throws Exception {
        if (m.equals("GET") && p.length == 1) {
            List<Appointment> list = q.containsKey("patientId")
                    ? appointmentDAO.getByPatient(toInt(q.get("patientId"), "patientId"))
                    : appointmentService.getAll();
            Map<Integer, String> pn = patientNames();
            Map<Integer, String> dn = doctorNames();
            List<String> items = new ArrayList<>();
            for (Appointment a : list) items.add(appointmentJson(a, pn, dn));
            return "[" + String.join(",", items) + "]";
        }
        if (m.equals("POST") && p.length == 1) {
            Appointment a = new Appointment();
            a.setPatientId(toInt(required(f, "patientId", "Patient"), "Patient"));
            a.setDoctorId(toInt(required(f, "doctorId", "Doctor"), "Doctor"));
            a.setAppointmentDate(toDate(required(f, "date", "Date")));
            a.setStartTime(toTime(required(f, "startTime", "Start time")));
            a.setEndTime(toTime(required(f, "endTime", "End time")));
            String err = appointmentService.book(a);
            if (err != null) throw new ApiException(409, err);
            return appointmentJson(a, patientNames(), doctorNames());
        }
        if (m.equals("POST") && p.length == 3) {
            int id = toInt(p[1], "id");
            boolean ok;
            switch (p[2]) {
                case "reschedule":
                    String err = appointmentService.reschedule(id, toDate(required(f, "date", "Date")),
                            toTime(required(f, "startTime", "Start time")), toTime(required(f, "endTime", "End time")));
                    if (err != null) throw new ApiException(409, err);
                    return "{\"ok\":true}";
                case "cancel": ok = appointmentService.cancel(id); break;
                case "complete": ok = appointmentService.complete(id); break;
                case "noshow": ok = appointmentService.markNoShow(id); break;
                default: throw new ApiException(404, "Unknown action.");
            }
            if (!ok) throw new ApiException(409, "Appointment not found, or it is no longer in Booked status.");
            return "{\"ok\":true}";
        }
        throw new ApiException(405, "Method not allowed.");
    }

    // ---------- Medical records ----------
    private static String records(String m, String[] p, Map<String, String> f, Map<String, String> q)
            throws Exception {
        if (m.equals("GET") && p.length == 1) {
            List<MedicalRecord> list = q.containsKey("patientId")
                    ? recordService.getByPatient(toInt(q.get("patientId"), "patientId"))
                    : recordDAO.getAll();
            Map<Integer, String> pn = patientNames();
            Map<Integer, String> dn = doctorNames();
            List<String> items = new ArrayList<>();
            for (MedicalRecord r : list) items.add(recordJson(r, pn, dn));
            return "[" + String.join(",", items) + "]";
        }
        if (m.equals("POST") && p.length == 1) {
            String err = recordService.addRecord(toInt(required(f, "appointmentId", "Appointment"), "Appointment"),
                    required(f, "diagnosis", "Diagnosis"), optional(f, "prescription"), optional(f, "visitNotes"));
            if (err != null) throw new ApiException(409, err);
            return "{\"ok\":true}";
        }
        if (m.equals("PUT") && p.length == 2) {
            String err = recordService.updateRecord(toInt(p[1], "id"), required(f, "diagnosis", "Diagnosis"),
                    optional(f, "prescription"), optional(f, "visitNotes"));
            if (err != null) throw new ApiException(404, err);
            return "{\"ok\":true}";
        }
        throw new ApiException(405, "Method not allowed.");
    }

    // ---------- Statistics (all numbers come from StatisticsService) ----------
    private static String stats(Map<String, String> q) throws Exception {
        LocalDate from = q.get("from") == null || q.get("from").isEmpty() ? null : toDate(q.get("from"));
        LocalDate to = q.get("to") == null || q.get("to").isEmpty() ? null : toDate(q.get("to"));

        List<Appointment> all = appointmentDAO.getAll();
        List<Appointment> list = statsService.filterByDate(all, from, to);
        List<Doctor> doctors = doctorDAO.getAll();
        Map<Integer, String> pn = patientNames();
        Map<Integer, String> dn = doctorNames();
        LocalDate today = LocalDate.now();

        StringBuilder sb = new StringBuilder("{");
        sb.append("\"from\":").append(q(from == null ? null : from.toString()));
        sb.append(",\"to\":").append(q(to == null ? null : to.toString()));
        sb.append(",\"totalPatients\":").append(pn.size());
        sb.append(",\"totalDoctors\":").append(doctors.size());
        sb.append(",\"totalAppointments\":").append(statsService.totalAppointments(list));
        sb.append(",\"todayAppointments\":").append(
                statsService.appointmentsPerDay(statsService.filterByDate(all, today, today)).getOrDefault(today, 0));
        sb.append(",\"cancellationRate\":").append(num(statsService.cancellationRate(list)));
        sb.append(",\"noShowRate\":").append(num(statsService.noShowRate(list)));
        int[] rf = statsService.repeatVsFirstTime(list);
        sb.append(",\"repeatPatients\":").append(rf[0]);
        sb.append(",\"firstTimePatients\":").append(rf[1]);

        List<String> fv = new ArrayList<>();
        for (Map.Entry<Integer, Integer> e : statsService.frequentVisitors(list, 5)) {
            fv.add("{\"patientId\":" + e.getKey() + ",\"name\":" + q(pn.get(e.getKey())) + ",\"visits\":" + e.getValue() + "}");
        }
        sb.append(",\"frequentVisitors\":[").append(String.join(",", fv)).append("]");

        List<String> groups = new ArrayList<>();
        for (Map.Entry<String, List<Integer>> g : statsService.groupByFrequency(list).entrySet()) {
            List<String> names = new ArrayList<>();
            for (int id : g.getValue()) names.add(q(pn.get(id)));
            groups.add(q(g.getKey()) + ":[" + String.join(",", names) + "]");
        }
        sb.append(",\"frequencyGroups\":{").append(String.join(",", groups)).append("}");

        Map<Integer, int[]> workload = statsService.workloadPerDoctor(list);
        Map<Integer, Double> util = statsService.utilizationPerDoctor(list, doctors, from, to);
        List<String> docs = new ArrayList<>();
        for (Doctor d : doctors) {
            int[] w = workload.getOrDefault(d.getDoctorId(), new int[2]);
            docs.add("{\"doctorId\":" + d.getDoctorId() + ",\"name\":" + q(d.getName())
                    + ",\"appointments\":" + w[0] + ",\"minutes\":" + w[1]
                    + ",\"utilization\":" + num(util.getOrDefault(d.getDoctorId(), 0.0)) + "}");
        }
        sb.append(",\"doctors\":[").append(String.join(",", docs)).append("]");

        Map<Integer, Integer> hours = statsService.busiestHours(list);
        Integer peakHour = statsService.peak(hours);
        sb.append(",\"busiestHour\":").append(peakHour == null ? "null"
                : q(String.format("%02d:00-%02d:59", peakHour, peakHour)));
        sb.append(",\"busiestHourCount\":").append(peakHour == null ? 0 : hours.get(peakHour));
        Map<DayOfWeek, Integer> days = statsService.busiestDays(list);
        DayOfWeek peakDay = statsService.peak(days);
        sb.append(",\"busiestDay\":").append(peakDay == null ? "null"
                : q(peakDay.getDisplayName(TextStyle.FULL, Locale.ENGLISH)));
        sb.append(",\"busiestDayCount\":").append(peakDay == null ? 0 : days.get(peakDay));

        sb.append(",\"perDay\":").append(mapJson(statsService.appointmentsPerDay(list)));
        sb.append(",\"perWeek\":").append(mapJson(statsService.appointmentsPerWeek(list)));
        sb.append(",\"perMonth\":").append(mapJson(statsService.appointmentsPerMonth(list)));
        sb.append("}");
        return sb.toString();
    }

    // ================= Helpers: names =================
    private static Map<Integer, String> patientNames() throws SQLException {
        Map<Integer, String> m = new LinkedHashMap<>();
        for (Patient p : patientDAO.getAll()) m.put(p.getPatientId(), p.getName());
        return m;
    }

    private static Map<Integer, String> doctorNames() throws SQLException {
        Map<Integer, String> m = new LinkedHashMap<>();
        for (Doctor d : doctorDAO.getAll()) m.put(d.getDoctorId(), d.getName());
        return m;
    }

    // ================= Helpers: reading input =================
    private static Map<String, String> parseForm(String s) {
        Map<String, String> map = new HashMap<>();
        if (s == null || s.isEmpty()) return map;
        for (String pair : s.split("&")) {
            if (pair.isEmpty()) continue;
            int i = pair.indexOf('=');
            String key = URLDecoder.decode(i < 0 ? pair : pair.substring(0, i), StandardCharsets.UTF_8);
            String val = i < 0 ? "" : URLDecoder.decode(pair.substring(i + 1), StandardCharsets.UTF_8);
            map.put(key, val);
        }
        return map;
    }

    private static String required(Map<String, String> f, String key, String label) throws ApiException {
        String v = f.get(key);
        if (v == null || v.trim().isEmpty()) throw new ApiException(400, label + " is required.");
        return v.trim();
    }

    private static String optional(Map<String, String> f, String key) {
        String v = f.get(key);
        return (v == null || v.trim().isEmpty()) ? null : v.trim();
    }

    private static int toInt(String s, String label) throws ApiException {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            throw new ApiException(400, label + " must be a whole number.");
        }
    }

    private static LocalDate toDate(String s) throws ApiException {
        try {
            return LocalDate.parse(s.trim());
        } catch (Exception e) {
            throw new ApiException(400, "Date must look like 2026-10-26.");
        }
    }

    private static LocalTime toTime(String s) throws ApiException {
        try {
            return LocalTime.parse(s.trim());
        } catch (Exception e) {
            throw new ApiException(400, "Time must look like 10:30.");
        }
    }

    // ================= Helpers: building JSON =================
    private static String q(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append("\"").toString();
    }

    private static String errorJson(String message) {
        return "{\"error\":" + q(message) + "}";
    }

    private static String num(double d) {
        return String.format(Locale.ROOT, "%.1f", d);
    }

    private static String hm(LocalTime t) {
        return String.format("%02d:%02d", t.getHour(), t.getMinute());
    }

    private static String mapJson(Map<?, Integer> map) {
        List<String> items = new ArrayList<>();
        for (Map.Entry<?, Integer> e : map.entrySet()) items.add(q(String.valueOf(e.getKey())) + ":" + e.getValue());
        return "{" + String.join(",", items) + "}";
    }

    private static String patientJson(Patient p) {
        return "{\"id\":" + p.getPatientId() + ",\"name\":" + q(p.getName()) + ",\"age\":" + p.getAge()
                + ",\"gender\":" + q(p.getGender()) + ",\"phone\":" + q(p.getPhone())
                + ",\"email\":" + q(p.getEmail()) + "}";
    }

    private static String doctorJson(Doctor d) {
        return "{\"id\":" + d.getDoctorId() + ",\"name\":" + q(d.getName())
                + ",\"specialization\":" + q(d.getSpecialization()) + ",\"phone\":" + q(d.getPhone())
                + ",\"cabinNo\":" + q(d.getCabinNo()) + ",\"availableDays\":" + q(d.getAvailableDays())
                + ",\"startTime\":" + q(hm(d.getStartTime())) + ",\"endTime\":" + q(hm(d.getEndTime())) + "}";
    }

    private static String appointmentJson(Appointment a, Map<Integer, String> pn, Map<Integer, String> dn) {
        return "{\"id\":" + a.getAppointmentId() + ",\"patientId\":" + a.getPatientId()
                + ",\"patientName\":" + q(pn.get(a.getPatientId())) + ",\"doctorId\":" + a.getDoctorId()
                + ",\"doctorName\":" + q(dn.get(a.getDoctorId())) + ",\"date\":" + q(a.getAppointmentDate().toString())
                + ",\"startTime\":" + q(hm(a.getStartTime())) + ",\"endTime\":" + q(hm(a.getEndTime()))
                + ",\"status\":" + q(a.getStatus()) + "}";
    }

    private static String recordJson(MedicalRecord r, Map<Integer, String> pn, Map<Integer, String> dn) {
        return "{\"id\":" + r.getRecordId() + ",\"appointmentId\":" + r.getAppointmentId()
                + ",\"patientId\":" + r.getPatientId() + ",\"patientName\":" + q(pn.get(r.getPatientId()))
                + ",\"doctorId\":" + r.getDoctorId() + ",\"doctorName\":" + q(dn.get(r.getDoctorId()))
                + ",\"diagnosis\":" + q(r.getDiagnosis()) + ",\"prescription\":" + q(r.getPrescription())
                + ",\"visitNotes\":" + q(r.getVisitNotes()) + ",\"recordDate\":" + q(r.getRecordDate().toString()) + "}";
    }
}
