package model;

import java.time.LocalDate;

public class MedicalRecord {
    private int recordId;
    private int patientId;
    private int doctorId;
    private int appointmentId;
    private String diagnosis;
    private String prescription;
    private String visitNotes;
    private LocalDate recordDate;

    public MedicalRecord() {}

    public MedicalRecord(int recordId, int patientId, int doctorId, int appointmentId,
                         String diagnosis, String prescription, String visitNotes, LocalDate recordDate) {
        this.recordId = recordId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.appointmentId = appointmentId;
        this.diagnosis = diagnosis;
        this.prescription = prescription;
        this.visitNotes = visitNotes;
        this.recordDate = recordDate;
    }

    public int getRecordId() { return recordId; }
    public void setRecordId(int recordId) { this.recordId = recordId; }
    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }
    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }
    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }
    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }
    public String getPrescription() { return prescription; }
    public void setPrescription(String prescription) { this.prescription = prescription; }
    public String getVisitNotes() { return visitNotes; }
    public void setVisitNotes(String visitNotes) { this.visitNotes = visitNotes; }
    public LocalDate getRecordDate() { return recordDate; }
    public void setRecordDate(LocalDate recordDate) { this.recordDate = recordDate; }

    @Override
    public String toString() {
        return "MedicalRecord[" + recordId + ", patient " + patientId + ", " + diagnosis + ", " + recordDate + "]";
    }
}
