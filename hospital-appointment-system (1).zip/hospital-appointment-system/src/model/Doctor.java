package model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.Locale;

public class Doctor {
    private int doctorId;
    private String name;
    private String specialization;
    private String phone;
    private String cabinNo;
    private String availableDays;   // e.g. "Monday,Wednesday,Friday"
    private LocalTime startTime;
    private LocalTime endTime;

    public Doctor() {}

    public Doctor(int doctorId, String name, String specialization, String phone,
                  String cabinNo, String availableDays, LocalTime startTime, LocalTime endTime) {
        this.doctorId = doctorId;
        this.name = name;
        this.specialization = specialization;
        this.phone = phone;
        this.cabinNo = cabinNo;
        this.availableDays = availableDays;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    // Does this doctor work on the given date?
    public boolean worksOn(LocalDate date) {
        String day = date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH); // "Monday"
        for (String d : availableDays.split(",")) {
            if (d.trim().equalsIgnoreCase(day)) return true;
        }
        return false;
    }

    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getCabinNo() { return cabinNo; }
    public void setCabinNo(String cabinNo) { this.cabinNo = cabinNo; }
    public String getAvailableDays() { return availableDays; }
    public void setAvailableDays(String availableDays) { this.availableDays = availableDays; }
    public LocalTime getStartTime() { return startTime; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
    public LocalTime getEndTime() { return endTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }

    @Override
    public String toString() {
        return "Doctor[" + doctorId + ", " + name + ", " + specialization + ", " + cabinNo + "]";
    }
}
