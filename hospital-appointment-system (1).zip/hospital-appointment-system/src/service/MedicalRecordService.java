package service;

import dao.AppointmentDAO;
import dao.MedicalRecordDAO;
import model.Appointment;
import model.MedicalRecord;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class MedicalRecordService {
    private final MedicalRecordDAO recordDAO = new MedicalRecordDAO();
    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    // Returns null if added, otherwise an error message.
    // Patient and doctor are taken from the appointment so they can never be inconsistent.
    public String addRecord(int appointmentId, String diagnosis, String prescription, String visitNotes)
            throws SQLException {
        Appointment a = appointmentDAO.getById(appointmentId);
        if (a == null) return "Appointment not found.";
        if (!"Completed".equals(a.getStatus())) return "Records can only be added for Completed appointments.";
        if (recordDAO.getByAppointmentId(appointmentId) != null) return "A record already exists for this appointment.";

        MedicalRecord r = new MedicalRecord(0, a.getPatientId(), a.getDoctorId(), appointmentId,
                diagnosis, prescription, visitNotes, LocalDate.now());
        recordDAO.add(r);
        return null;
    }

    public String updateRecord(int recordId, String diagnosis, String prescription, String visitNotes)
            throws SQLException {
        MedicalRecord r = recordDAO.getById(recordId);
        if (r == null) return "Record not found.";
        r.setDiagnosis(diagnosis);
        r.setPrescription(prescription);
        r.setVisitNotes(visitNotes);
        recordDAO.update(r);
        return null;
    }

    public List<MedicalRecord> getByPatient(int patientId) throws SQLException {
        return recordDAO.getByPatient(patientId);
    }
}
