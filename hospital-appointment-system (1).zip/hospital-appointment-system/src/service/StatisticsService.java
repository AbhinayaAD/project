package service;

import model.Appointment;
import model.Doctor;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.temporal.IsoFields;
import java.util.*;

// All statistics are calculated in Java from a list of appointments.
// "Visit" = an appointment that is Booked or Completed (cancelled and no-show are not visits).
public class StatisticsService {

    // ---------- Filtering ----------

    // from / to can be null (no limit on that side). Both dates are inclusive.
    public List<Appointment> filterByDate(List<Appointment> all, LocalDate from, LocalDate to) {
        List<Appointment> result = new ArrayList<>();
        for (Appointment a : all) {
            LocalDate d = a.getAppointmentDate();
            if (from != null && d.isBefore(from)) continue;
            if (to != null && d.isAfter(to)) continue;
            result.add(a);
        }
        return result;
    }

    private boolean isVisit(Appointment a) {
        return "Booked".equals(a.getStatus()) || "Completed".equals(a.getStatus());
    }

    // ---------- Overview ----------

    public int totalAppointments(List<Appointment> list) {
        return list.size();
    }

    public Map<LocalDate, Integer> appointmentsPerDay(List<Appointment> list) {
        Map<LocalDate, Integer> map = new TreeMap<>();
        for (Appointment a : list) {
            if (isVisit(a)) map.merge(a.getAppointmentDate(), 1, Integer::sum);
        }
        return map;
    }

    public Map<String, Integer> appointmentsPerWeek(List<Appointment> list) {
        Map<String, Integer> map = new TreeMap<>();
        for (Appointment a : list) {
            if (!isVisit(a)) continue;
            LocalDate d = a.getAppointmentDate();
            String key = String.format("%d-W%02d", d.get(IsoFields.WEEK_BASED_YEAR),
                    d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR));
            map.merge(key, 1, Integer::sum);
        }
        return map;
    }

    public Map<String, Integer> appointmentsPerMonth(List<Appointment> list) {
        Map<String, Integer> map = new TreeMap<>();
        for (Appointment a : list) {
            if (isVisit(a)) map.merge(YearMonth.from(a.getAppointmentDate()).toString(), 1, Integer::sum);
        }
        return map;
    }

    // ---------- Patient visits ----------

    // patientId -> number of visits
    public Map<Integer, Integer> visitsPerPatient(List<Appointment> list) {
        Map<Integer, Integer> map = new HashMap<>();
        for (Appointment a : list) {
            if (isVisit(a)) map.merge(a.getPatientId(), 1, Integer::sum);
        }
        return map;
    }

    // Returns {repeatPatients, firstTimePatients} within the given list
    public int[] repeatVsFirstTime(List<Appointment> list) {
        int repeat = 0, first = 0;
        for (int visits : visitsPerPatient(list).values()) {
            if (visits >= 2) repeat++;
            else first++;
        }
        return new int[]{repeat, first};
    }

    // Top N patients by number of visits (highest first)
    public List<Map.Entry<Integer, Integer>> frequentVisitors(List<Appointment> list, int topN) {
        List<Map.Entry<Integer, Integer>> entries = new ArrayList<>(visitsPerPatient(list).entrySet());
        entries.sort((x, y) -> {
            int cmp = Integer.compare(y.getValue(), x.getValue());
            return cmp != 0 ? cmp : Integer.compare(x.getKey(), y.getKey());
        });
        return entries.subList(0, Math.min(topN, entries.size()));
    }

    // Groups patient ids into: "1 visit", "2-3 visits", "4+ visits"
    public Map<String, List<Integer>> groupByFrequency(List<Appointment> list) {
        Map<String, List<Integer>> groups = new LinkedHashMap<>();
        groups.put("1 visit", new ArrayList<>());
        groups.put("2-3 visits", new ArrayList<>());
        groups.put("4+ visits", new ArrayList<>());
        for (Map.Entry<Integer, Integer> e : visitsPerPatient(list).entrySet()) {
            int v = e.getValue();
            String key = v == 1 ? "1 visit" : (v <= 3 ? "2-3 visits" : "4+ visits");
            groups.get(key).add(e.getKey());
        }
        return groups;
    }

    // ---------- Doctor workload and utilization ----------

    // doctorId -> {number of appointments, total booked minutes}
    public Map<Integer, int[]> workloadPerDoctor(List<Appointment> list) {
        Map<Integer, int[]> map = new TreeMap<>();
        for (Appointment a : list) {
            if (!isVisit(a)) continue;
            int[] w = map.computeIfAbsent(a.getDoctorId(), k -> new int[2]);
            w[0]++;
            w[1] += (int) Duration.between(a.getStartTime(), a.getEndTime()).toMinutes();
        }
        return map;
    }

    // doctorId -> utilization % = booked minutes / available minutes * 100.
    // Available minutes = for every day in [from, to] the doctor works: working hours minus lunch break.
    // If from/to are null, the earliest/latest appointment date in the list is used.
    public Map<Integer, Double> utilizationPerDoctor(List<Appointment> list, List<Doctor> doctors,
                                                     LocalDate from, LocalDate to) {
        Map<Integer, Double> result = new TreeMap<>();
        if (list.isEmpty()) return result;

        if (from == null || to == null) {
            LocalDate min = list.get(0).getAppointmentDate();
            LocalDate max = min;
            for (Appointment a : list) {
                if (a.getAppointmentDate().isBefore(min)) min = a.getAppointmentDate();
                if (a.getAppointmentDate().isAfter(max)) max = a.getAppointmentDate();
            }
            if (from == null) from = min;
            if (to == null) to = max;
        }

        Map<Integer, int[]> workload = workloadPerDoctor(list);
        for (Doctor doc : doctors) {
            long available = 0;
            for (LocalDate d = from; !d.isAfter(to); d = d.plusDays(1)) {
                if (doc.worksOn(d)) available += dailyAvailableMinutes(doc);
            }
            int booked = workload.containsKey(doc.getDoctorId()) ? workload.get(doc.getDoctorId())[1] : 0;
            result.put(doc.getDoctorId(), available == 0 ? 0.0 : booked * 100.0 / available);
        }
        return result;
    }

    // Working hours minus the part that overlaps the lunch break
    private long dailyAvailableMinutes(Doctor doc) {
        long total = Duration.between(doc.getStartTime(), doc.getEndTime()).toMinutes();
        LocalTime overlapStart = doc.getStartTime().isAfter(AppointmentService.LUNCH_START)
                ? doc.getStartTime() : AppointmentService.LUNCH_START;
        LocalTime overlapEnd = doc.getEndTime().isBefore(AppointmentService.LUNCH_END)
                ? doc.getEndTime() : AppointmentService.LUNCH_END;
        long lunch = overlapEnd.isAfter(overlapStart) ? Duration.between(overlapStart, overlapEnd).toMinutes() : 0;
        return total - lunch;
    }

    // ---------- Peak times ----------

    // start hour (e.g. 10 = 10:00-10:59) -> number of appointments
    public Map<Integer, Integer> busiestHours(List<Appointment> list) {
        Map<Integer, Integer> map = new TreeMap<>();
        for (Appointment a : list) {
            if (isVisit(a)) map.merge(a.getStartTime().getHour(), 1, Integer::sum);
        }
        return map;
    }

    public Map<DayOfWeek, Integer> busiestDays(List<Appointment> list) {
        Map<DayOfWeek, Integer> map = new TreeMap<>();
        for (Appointment a : list) {
            if (isVisit(a)) map.merge(a.getAppointmentDate().getDayOfWeek(), 1, Integer::sum);
        }
        return map;
    }

    // Returns the key with the highest count, or null if the map is empty
    public <K> K peak(Map<K, Integer> counts) {
        K best = null;
        int max = -1;
        for (Map.Entry<K, Integer> e : counts.entrySet()) {
            if (e.getValue() > max) {
                max = e.getValue();
                best = e.getKey();
            }
        }
        return best;
    }

    // ---------- Rates (denominator = ALL appointments in the list) ----------

    public double cancellationRate(List<Appointment> list) {
        return rate(list, "Cancelled");
    }

    public double noShowRate(List<Appointment> list) {
        return rate(list, "No-Show");
    }

    private double rate(List<Appointment> list, String status) {
        if (list.isEmpty()) return 0.0;
        int count = 0;
        for (Appointment a : list) {
            if (status.equals(a.getStatus())) count++;
        }
        return count * 100.0 / list.size();
    }
}
