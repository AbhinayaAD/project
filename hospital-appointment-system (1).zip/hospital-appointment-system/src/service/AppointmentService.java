package service;

import dao.AppointmentDAO;
import dao.DoctorDAO;
import dao.PatientDAO;
import model.Appointment;
import model.Doctor;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class AppointmentService {
    public static final LocalTime LUNCH_START = LocalTime.of(13, 0);
    public static final LocalTime LUNCH_END = LocalTime.of(14, 0);

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();
    private final DoctorDAO doctorDAO = new DoctorDAO();
    private final PatientDAO patientDAO = new PatientDAO();

    // Returns null if the slot is valid, otherwise an error message
    public String validate(Doctor doctor, Appointment newAppt) throws SQLException {
        LocalTime start = newAppt.getStartTime();
        LocalTime end = newAppt.getEndTime();

        if (!end.isAfter(start)) {
            return "End time must be after start time.";
        }
        if (!doctor.worksOn(newAppt.getAppointmentDate())) {
            return "Doctor does not work on this day.";
        }
        if (start.isBefore(doctor.getStartTime()) || end.isAfter(doctor.getEndTime())) {
            return "Outside doctor's working hours (" + doctor.getStartTime() + " - " + doctor.getEndTime() + ").";
        }
        if (start.isBefore(LUNCH_END) && end.isAfter(LUNCH_START)) {
            return "Appointment overlaps lunch break (13:00-14:00).";
        }
        List<Appointment> sameDay = appointmentDAO.getByDoctorAndDate(
                newAppt.getDoctorId(), newAppt.getAppointmentDate());
        for (Appointment a : sameDay) {
            if (a.getAppointmentId() == newAppt.getAppointmentId()) continue; // skip itself (reschedule)
            if (!"Booked".equals(a.getStatus())) continue; // cancelled / completed / no-show don't block
            if (start.isBefore(a.getEndTime()) && end.isAfter(a.getStartTime())) {
                return "Time conflict with an existing appointment (" + a.getStartTime() + " - " + a.getEndTime() + ").";
            }
        }
        return null;
    }

    // Returns null if booked, otherwise an error message
    public String book(Appointment appt) throws SQLException {
        if (patientDAO.getById(appt.getPatientId()) == null) return "Patient not found.";
        Doctor doctor = doctorDAO.getById(appt.getDoctorId());
        if (doctor == null) return "Doctor not found.";

        String error = validate(doctor, appt);
        if (error != null) return error;

        appt.setStatus("Booked");
        appointmentDAO.add(appt);
        return null;
    }

    // Moves a Booked appointment to a new slot. The original changes only if the new slot is valid.
    public String reschedule(int appointmentId, LocalDate newDate, LocalTime newStart, LocalTime newEnd)
            throws SQLException {
        Appointment existing = appointmentDAO.getById(appointmentId);
        if (existing == null) return "Appointment not found.";
        if (!"Booked".equals(existing.getStatus())) return "Only Booked appointments can be rescheduled.";

        Doctor doctor = doctorDAO.getById(existing.getDoctorId());
        Appointment proposed = new Appointment(appointmentId, existing.getPatientId(),
                existing.getDoctorId(), newDate, newStart, newEnd, "Booked");
        String error = validate(doctor, proposed);
        if (error != null) return error;

        appointmentDAO.updateSlot(appointmentId, newDate, newStart, newEnd);
        return null;
    }

    public boolean cancel(int appointmentId) throws SQLException {
        return changeStatus(appointmentId, "Cancelled");
    }

    public boolean complete(int appointmentId) throws SQLException {
        return changeStatus(appointmentId, "Completed");
    }

    public boolean markNoShow(int appointmentId) throws SQLException {
        return changeStatus(appointmentId, "No-Show");
    }

    // Only a Booked appointment can move to another status
    private boolean changeStatus(int appointmentId, String newStatus) throws SQLException {
        Appointment a = appointmentDAO.getById(appointmentId);
        if (a == null || !"Booked".equals(a.getStatus())) return false;
        return appointmentDAO.updateStatus(appointmentId, newStatus);
    }

    public List<Appointment> getAll() throws SQLException {
        return appointmentDAO.getAll();
    }

    public Appointment findById(int id) throws SQLException {
        return appointmentDAO.getById(id);
    }
}
