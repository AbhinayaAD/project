package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // CHANGE THE PASSWORD below to your MySQL root password
    private static final String URL = System.getProperty("db.url",
            "jdbc:mysql://localhost:3306/ClinicDB?useSSL=false&allowPublicKeyRetrieval=true");
    private static final String USER = System.getProperty("db.user", "root");
    private static final String PASSWORD = System.getProperty("db.password", "your_password_here");

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
