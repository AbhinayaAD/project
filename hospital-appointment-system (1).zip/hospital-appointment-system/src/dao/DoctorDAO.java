package dao;

import database.DatabaseConnection;
import model.Doctor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO {

    public void add(Doctor d) throws SQLException {
        String sql = "INSERT INTO Doctor (name, specialization, phone, cabin_no, available_days, start_time, end_time) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            fill(ps, d);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) d.setDoctorId(keys.getInt(1));
            }
        }
    }

    public List<Doctor> getAll() throws SQLException {
        List<Doctor> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Doctor ORDER BY doctor_id")) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public Doctor getById(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM Doctor WHERE doctor_id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public boolean update(Doctor d) throws SQLException {
        String sql = "UPDATE Doctor SET name=?, specialization=?, phone=?, cabin_no=?, available_days=?, "
                + "start_time=?, end_time=? WHERE doctor_id=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            fill(ps, d);
            ps.setInt(8, d.getDoctorId());
            return ps.executeUpdate() > 0;
        }
    }

    private void fill(PreparedStatement ps, Doctor d) throws SQLException {
        ps.setString(1, d.getName());
        ps.setString(2, d.getSpecialization());
        ps.setString(3, d.getPhone());
        ps.setString(4, d.getCabinNo());
        ps.setString(5, d.getAvailableDays());
        ps.setTime(6, Time.valueOf(d.getStartTime()));
        ps.setTime(7, Time.valueOf(d.getEndTime()));
    }

    private Doctor map(ResultSet rs) throws SQLException {
        return new Doctor(rs.getInt("doctor_id"), rs.getString("name"), rs.getString("specialization"),
                rs.getString("phone"), rs.getString("cabin_no"), rs.getString("available_days"),
                rs.getTime("start_time").toLocalTime(), rs.getTime("end_time").toLocalTime());
    }
}
