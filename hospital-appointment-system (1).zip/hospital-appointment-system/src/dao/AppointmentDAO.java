package dao;

import database.DatabaseConnection;
import model.Appointment;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {
    private static final String ORDER = " ORDER BY appointment_date, appointment_start_time";

    public void add(Appointment a) throws SQLException {
        String sql = "INSERT INTO Appointment (patient_id, doctor_id, appointment_date, "
                + "appointment_start_time, appointment_end_time, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, a.getPatientId());
            ps.setInt(2, a.getDoctorId());
            ps.setDate(3, Date.valueOf(a.getAppointmentDate()));
            ps.setTime(4, Time.valueOf(a.getStartTime()));
            ps.setTime(5, Time.valueOf(a.getEndTime()));
            ps.setString(6, a.getStatus());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) a.setAppointmentId(keys.getInt(1));
            }
        }
    }

    public List<Appointment> getAll() throws SQLException {
        return query("SELECT * FROM Appointment" + ORDER);
    }

    public List<Appointment> getByDoctorAndDate(int doctorId, LocalDate date) throws SQLException {
        return query("SELECT * FROM Appointment WHERE doctor_id = ? AND appointment_date = ?" + ORDER,
                doctorId, Date.valueOf(date));
    }

    public List<Appointment> getByPatient(int patientId) throws SQLException {
        return query("SELECT * FROM Appointment WHERE patient_id = ?" + ORDER, patientId);
    }

    public Appointment getById(int id) throws SQLException {
        List<Appointment> list = query("SELECT * FROM Appointment WHERE appointment_id = ?", id);
        return list.isEmpty() ? null : list.get(0);
    }

    public boolean updateStatus(int id, String status) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE Appointment SET status = ? WHERE appointment_id = ?")) {
            ps.setString(1, status);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateSlot(int id, LocalDate date, LocalTime start, LocalTime end) throws SQLException {
        String sql = "UPDATE Appointment SET appointment_date=?, appointment_start_time=?, "
                + "appointment_end_time=? WHERE appointment_id=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            ps.setTime(2, Time.valueOf(start));
            ps.setTime(3, Time.valueOf(end));
            ps.setInt(4, id);
            return ps.executeUpdate() > 0;
        }
    }

    // Runs a SELECT with the given parameters and maps every row to an Appointment
    private List<Appointment> query(String sql, Object... params) throws SQLException {
        List<Appointment> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Appointment(rs.getInt("appointment_id"), rs.getInt("patient_id"),
                            rs.getInt("doctor_id"), rs.getDate("appointment_date").toLocalDate(),
                            rs.getTime("appointment_start_time").toLocalTime(),
                            rs.getTime("appointment_end_time").toLocalTime(), rs.getString("status")));
                }
            }
        }
        return list;
    }
}
