package dao;

import database.DatabaseConnection;
import model.Patient;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    public void add(Patient p) throws SQLException {
        String sql = "INSERT INTO Patient (name, age, gender, phone, email) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getName());
            ps.setInt(2, p.getAge());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getPhone());
            ps.setString(5, p.getEmail());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) p.setPatientId(keys.getInt(1));
            }
        }
    }

    public List<Patient> getAll() throws SQLException {
        List<Patient> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Patient ORDER BY patient_id")) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public Patient getById(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM Patient WHERE patient_id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public boolean update(Patient p) throws SQLException {
        String sql = "UPDATE Patient SET name=?, age=?, gender=?, phone=?, email=? WHERE patient_id=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setInt(2, p.getAge());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getPhone());
            ps.setString(5, p.getEmail());
            ps.setInt(6, p.getPatientId());
            return ps.executeUpdate() > 0;
        }
    }

    private Patient map(ResultSet rs) throws SQLException {
        return new Patient(rs.getInt("patient_id"), rs.getString("name"), rs.getInt("age"),
                rs.getString("gender"), rs.getString("phone"), rs.getString("email"));
    }
}
