package dao;

import database.DatabaseConnection;
import model.MedicalRecord;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO {

    public void add(MedicalRecord r) throws SQLException {
        String sql = "INSERT INTO Medical_Record (patient_id, doctor_id, appointment_id, diagnosis, "
                + "prescription, visit_notes, record_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, r.getPatientId());
            ps.setInt(2, r.getDoctorId());
            ps.setInt(3, r.getAppointmentId());
            ps.setString(4, r.getDiagnosis());
            ps.setString(5, r.getPrescription());
            ps.setString(6, r.getVisitNotes());
            ps.setDate(7, Date.valueOf(r.getRecordDate()));
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) r.setRecordId(keys.getInt(1));
            }
        }
    }

    public List<MedicalRecord> getAll() throws SQLException {
        return query("SELECT * FROM Medical_Record ORDER BY record_date DESC, record_id DESC");
    }

    public List<MedicalRecord> getByPatient(int patientId) throws SQLException {
        return query("SELECT * FROM Medical_Record WHERE patient_id = ? ORDER BY record_date DESC", patientId);
    }

    public MedicalRecord getByAppointmentId(int appointmentId) throws SQLException {
        List<MedicalRecord> list = query("SELECT * FROM Medical_Record WHERE appointment_id = ?", appointmentId);
        return list.isEmpty() ? null : list.get(0);
    }

    public MedicalRecord getById(int recordId) throws SQLException {
        List<MedicalRecord> list = query("SELECT * FROM Medical_Record WHERE record_id = ?", recordId);
        return list.isEmpty() ? null : list.get(0);
    }

    public boolean update(MedicalRecord r) throws SQLException {
        String sql = "UPDATE Medical_Record SET diagnosis=?, prescription=?, visit_notes=? WHERE record_id=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, r.getDiagnosis());
            ps.setString(2, r.getPrescription());
            ps.setString(3, r.getVisitNotes());
            ps.setInt(4, r.getRecordId());
            return ps.executeUpdate() > 0;
        }
    }

    private List<MedicalRecord> query(String sql, int... params) throws SQLException {
        List<MedicalRecord> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setInt(i + 1, params[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new MedicalRecord(rs.getInt("record_id"), rs.getInt("patient_id"),
                            rs.getInt("doctor_id"), rs.getInt("appointment_id"), rs.getString("diagnosis"),
                            rs.getString("prescription"), rs.getString("visit_notes"),
                            rs.getDate("record_date").toLocalDate()));
                }
            }
        }
        return list;
    }
}
