# CarePoint Clinic: Hospital Appointment Scheduling and Patient Statistics System

Java + JDBC + MySQL backend, web frontend (HTML/CSS/JS), plus an optional console menu.

## Run the web app
1. Run `sql/hosp_management_sys_proj_fixed.sql` in MySQL Workbench (recreates ClinicDB with sample data).
2. Put the MySQL Connector/J `.jar` in `lib/` (see the note in that folder).
3. Open `src/database/DatabaseConnection.java` and set your MySQL password.
4. Open this folder in VS Code and run `src/app/WebServer.java`.
5. Open http://localhost:8080 in your browser.

(`src/app/Main.java` is the console version of the same app.)

## Structure
- `frontend/`  index.html (single-page UI that calls the Java API)
- `src/model`    Patient, Doctor, Appointment, MedicalRecord
- `src/service`  AppointmentService (validation), StatisticsService (analytics), MedicalRecordService
- `src/dao`      JDBC / SQL for each table
- `src/database` DatabaseConnection
- `src/app`      WebServer (HTTP + JSON API, serves the frontend), Main (console menu)
- `sql/`         database script
